import React from 'react';

// Styles
import { GlobalStyle } from './GlobalStyle';

function App() {
  return (
    <div className="App">
      Start here.
      <GlobalStyle />
    </div>
  );
}

export default App;
