import { Spinner } from './Spinner.styles';

export default Spinner;
